// TelnetServer.cpp : implementation file
//

#include "stdafx.h"
#include "TelnetSvr.h"
#include "TelnetServer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTelnetServer

CTelnetServer::CTelnetServer(int port, HWND hWnd)
{
	WSADATA wsaData;
	ListenSocket = INVALID_SOCKET;
	AcceptSocket = INVALID_SOCKET;
	CString str;
	bConnected = FALSE;
	bClosed = FALSE;
	nPort = port;
	hWnd = NULL;
	memset(bufRcvd, 0, 255);
	str2send.Empty();
	n2send = nRcvd = 0;
	chLastSent.Empty();
    int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (iResult != NO_ERROR) 
	{

        TRACE("WSAStartup failed with error: %ld\n", iResult);
//        return 1;
    }
	else
	{
		ListenSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
		if (ListenSocket == INVALID_SOCKET) 
		{
			str.Format("socket failed with error: %ld\n", WSAGetLastError());
			TRACE(str);
			WSACleanup();
	 //       return 1;
		}
		else
		{
			SOCKADDR_IN service;
			service.sin_family = AF_INET;
			service.sin_addr.s_addr = htonl(INADDR_ANY);
			service.sin_port = htons(nPort);
			SOCKADDR_IN sa;
			int nAddrLen = sizeof(service);
			if ((bind(ListenSocket, (SOCKADDR *) & service, sizeof (service)) == SOCKET_ERROR) 
				|| (getsockname(ListenSocket, (LPSOCKADDR)&sa, &nAddrLen) == SOCKET_ERROR) 
				|| (listen(ListenSocket, 1) == SOCKET_ERROR)) 
			{
				str.Format("socket initialization error: %ld\n", WSAGetLastError());
				TRACE(str);
				closesocket(ListenSocket);
				WSACleanup();
			 //       return 1;
			}
			else
			{
				pThread = new CWinThread;
				if (! pThread)
				{
					TRACE("Thread alloc failure");
//					ASSERT(0);
				}
				else
				{
					pThread = AfxBeginThread(SocketThread, this);
					if (!pThread)
					{
						TRACE("Thread start failure");
//						ASSERT(0);
					}
					else
					{
						TRACE("Thread started...Wating for client to connect...");
					}
				}
			}
		}
	}
}

CTelnetServer::~CTelnetServer()
{
	if(pThread)
	{
		pThread->SuspendThread();
		pThread = NULL;
	}
	closesocket(ListenSocket);
	WSACleanup();
}


/////////////////////////////////////////////////////////////////////////////
// CTelnetServer member functions

UINT CTelnetServer::SocketThread(LPVOID pParam)
{
	CTelnetServer* p = (CTelnetServer*) pParam;
	CString str;
	int nLen;
	for (;;)
	{
		if (p->n2send>0)
		{
			nLen = 0;
			nLen = ::send(p->AcceptSocket, p->str2send.GetBuffer(0), p->n2send, 0);
			if (nLen <= 0)
			{
				theApp.Sleep2(25);
				continue;
			}
			else if ((nLen>0) && (nLen == p->n2send))
			{
				theApp.Log(p->str2send.GetBuffer(0));
				p->n2send = 0;
				p->chLastSent.Format("%s", p->str2send.GetBuffer(0));
				p->str2send.Empty();
			}
		}
		if (p->nRcvd>5)
		{
			if ((p->bufRcvd[p->nRcvd-1]==13))
			{	
				p->bufRcvd[p->nRcvd-1]=0;
				p->MakeTelnetReply(p->bufRcvd);
				memset(p->bufRcvd,0,255);
				p->nRcvd=0;
			}
		}
		theApp.Sleep2(50);
	}
	return 0;
}

void CTelnetServer::FDAcceptSocket()
{
// 	CSelectMode  m_cSelectMode;
	static       SOCKADDR_IN addr;
	static int   nAddrLen = sizeof(addr);
	int			 nSocketError = 0;
	CString str;

	if (bConnected)
	{ 
		closesocket(ListenSocket);
		bConnected = FALSE;
	}
//		Log("Closing old socket",3);
	if (bClosed)
	{
		ListenSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
		if (ListenSocket == INVALID_SOCKET) 
		{
			str.Format("socket failed with error: %ld\n", WSAGetLastError());
			TRACE(str);
			WSACleanup();
	 //       return 1;
		}
		else
		{
			SOCKADDR_IN service;
			service.sin_family = AF_INET;
			service.sin_addr.s_addr = htonl(INADDR_ANY);
			service.sin_port = htons(nPort);
			SOCKADDR_IN sa;
			int nAddrLen = sizeof(service);
			if ((bind(ListenSocket, (SOCKADDR *) & service, sizeof (service)) == SOCKET_ERROR) 
				|| (getsockname(ListenSocket, (LPSOCKADDR)&sa, &nAddrLen) == SOCKET_ERROR) 
				|| (listen(ListenSocket, 1) == SOCKET_ERROR)) 
			{
				str.Format("socket initialization error: %ld\n", WSAGetLastError());
				TRACE(str);
				closesocket(ListenSocket);
				WSACleanup();
			 //       return 1;
			}
			bClosed = FALSE;
		}
	}
	if (!bConnected)
	{
		AcceptSocket = accept(ListenSocket , (LPSOCKADDR)&addr , &nAddrLen);
		if (AcceptSocket == INVALID_SOCKET)
		{
			nSocketError = WSAGetLastError();
			str.Format("Connection Accept Error %ld\n", nSocketError);
			TRACE(str);
		}
		else
		{
			TRACE("Connection Accepted\n");
			bConnected = TRUE;
			str2send += "<TELNET SERVER ONLINE\r";
			n2send = str2send.GetLength();
			IPAddress.Format("%s", inet_ntoa(addr.sin_addr));
		}
		
	}
	theApp.Log("Telnet socket connected");
}

void CTelnetServer::FDCloseSocket()
{
	CString str;
	if (ListenSocket != INVALID_SOCKET)
	{
		closesocket(ListenSocket);
		bConnected = FALSE;
		bClosed = TRUE;
		TRACE("Socket closed\n");
	}
		ListenSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
		if (ListenSocket == INVALID_SOCKET) 
		{
			str.Format("socket failed with error: %ld\n", WSAGetLastError());
			TRACE(str);
			WSACleanup();
	 //       return 1;
		}
		else
		{
			SOCKADDR_IN service;
			service.sin_family = AF_INET;
			service.sin_addr.s_addr = htonl(INADDR_ANY);
			service.sin_port = htons(nPort);
			SOCKADDR_IN sa;
			int nAddrLen = sizeof(service);
			if ((bind(ListenSocket, (SOCKADDR *) & service, sizeof (service)) == SOCKET_ERROR) 
				|| (getsockname(ListenSocket, (LPSOCKADDR)&sa, &nAddrLen) == SOCKET_ERROR) 
				|| (!AsyncSelect(hWnd))
				|| (listen(ListenSocket, 1) == SOCKET_ERROR)) 
			{
				str.Format("socket initialization error: %ld\n", WSAGetLastError());
				TRACE(str);
				closesocket(ListenSocket);
				WSACleanup();
			 //       return 1;
			}
			bClosed = FALSE;
		}
	theApp.Log("Telnet socket closed");
}

void CTelnetServer::FDReadSocket()
{
	int i, nLen;
	CString str;
	char buff[255];
	nLen = ::recv(AcceptSocket, buff, 255, 0);
	if (nLen > 0)
	{
		for (i=0;i<nLen;i++)
		{
			if ((buff[i]>=0x61)&&(buff[i]<=0x7A)) //'a'-'z'
				buff[i] -= 0x20;					//convert smalls to capitals
			bufRcvd[nRcvd+i] = buff[i];
		}
		if (nRcvd+nLen<254)
			nRcvd += nLen;
		else
			nRcvd = 0;
		if (bufRcvd[nRcvd-1] == 10)
		{
			bufRcvd[nRcvd-1] = 0;
			nRcvd--;
		}
		if (bufRcvd[nRcvd-1] == 13)
		{
			str.Format("Telnet rcvd: %s\n", bufRcvd);
			TRACE(str);
			theApp.Log(str.GetBuffer(0));
		}
	}
	else if (nLen == SOCKET_ERROR)
    {
		nLen = WSAGetLastError();
		str.Format("Rcvd error: %ld\n", nLen);
		TRACE(str);
	}
}

BOOL CTelnetServer::AsyncSelect(HWND hwnd)
{
	hWnd = hwnd;
	return (WSAAsyncSelect(ListenSocket, hWnd, WM_USER_ASYNC_SELECT, FD_ACCEPT | FD_CLOSE | FD_READ) != INVALID_SOCKET);
}

void CTelnetServer::MakeTelnetReply(char* buf)
{
	CString cs;
	int i, d[6];
	float f[2];
	WORD w;
	cs.Format("%s", buf);
	str2send.Empty();
	if (cs == "GETDATA")
	{
		str2send.Format("<%s\r", "DATA 123");
	}
	else if (cs == "SETDATA")
	{
		str2send.Format("<%s\r", "DATA SET");
	}
	else if (cs == "GETPARAM")
	{
		str2send.Format("<%s\r","PARAM 321");
	}
	else if (cs == "SETPARAM")
	{
		str2send.Format("<%s\r","PARAM SET");
	}
	else
	{
		str2send.Format("<%s\r", "WRONG ENTRY");
	}
	n2send = str2send.GetLength();
	
}