// TelnetSvr.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "TelnetSvr.h"
#include "TelnetSvrDlg.h"
#include <mmsystem.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTelnetSvrApp

BEGIN_MESSAGE_MAP(CTelnetSvrApp, CWinApp)
	//{{AFX_MSG_MAP(CTelnetSvrApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTelnetSvrApp construction

CTelnetSvrApp::CTelnetSvrApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CTelnetSvrApp object

CTelnetSvrApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CTelnetSvrApp initialization

BOOL CTelnetSvrApp::InitInstance()
{
	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CTelnetSvrDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

void CTelnetSvrApp::Sleep2(int nTime)
{
	Sleep(nTime);
	return;
	DWORD time1, time2;
	time1 = timeGetTime();
	time2 = time1;
	while(time2-time1<nTime)
	{
		MSG msg;
		while (PeekMessage(&msg, NULL, NULL, NULL, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		time2 = timeGetTime();
	}
}

void CTelnetSvrApp::Log(char* msg)
{
	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	char winini[MAX_PATH];
	CString direc, name;

	CTime tme = CTime::GetCurrentTime();

	GetModuleFileName(NULL, winini, 255);
	_splitpath(winini, drive, dir, fname, ext ); 
	
	direc.Format("%s%sLog\\", drive, dir);

	int nTemp = ::GetFileAttributes(direc);
	if (!(FILE_ATTRIBUTE_DIRECTORY & nTemp) || (nTemp == -1))
	{
		if (!::CreateDirectory(direc, NULL))
		{
			return;
		}
	}
	direc += tme.Format("Y%y%B\\");
	nTemp = ::GetFileAttributes(direc);
	if (!(FILE_ATTRIBUTE_DIRECTORY & nTemp) || (nTemp == -1))
	{
		if (!::CreateDirectory(direc, NULL))
		{
			return;
		}
	}

	name.Format("%sL%s%s", direc, tme.Format("%y%m%d"), ".LOG");

	FILE* fp = fopen(name, "ab");
	if (fp)
	{
		fprintf(fp, "%s\t%s\r\n", tme.Format("%H:%M:%S"), msg);
		fclose(fp);
	}

}
