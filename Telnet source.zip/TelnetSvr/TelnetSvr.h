// TelnetSvr.h : main header file for the TELNETSVR application
//

#if !defined(AFX_TELNETSVR_H__AC299033_D595_4618_81FB_D22618BAD284__INCLUDED_)
#define AFX_TELNETSVR_H__AC299033_D595_4618_81FB_D22618BAD284__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#define WM_USER_ASYNC_SELECT  WM_USER+215

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CTelnetSvrApp:
// See TelnetSvr.cpp for the implementation of this class
//

class CTelnetSvrApp : public CWinApp
{
public:
	CTelnetSvrApp();
	void Sleep2(int nTime);
	void Log(char* str);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTelnetSvrApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTelnetSvrApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

extern CTelnetSvrApp theApp;
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TELNETSVR_H__AC299033_D595_4618_81FB_D22618BAD284__INCLUDED_)
