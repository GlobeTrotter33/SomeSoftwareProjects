#if !defined(AFX_TELNETSERVER_H__C6AEB3B2_1678_40C3_80DB_FE1D135BF17B__INCLUDED_)
#define AFX_TELNETSERVER_H__C6AEB3B2_1678_40C3_80DB_FE1D135BF17B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TelnetServer.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTelnetServer command target

class CTelnetServer
{
// Attributes
	CWinThread* pThread;
	SOCKET AcceptSocket;
	static UINT	SocketThread(LPVOID pParam);
	BOOL bClosed;
	HWND hWnd;
	int nPort;
	int n2send, nRcvd;
public:
	CString str2send;
	char bufRcvd[512];
	BOOL bConnected;
	void FDAcceptSocket();
	void FDCloseSocket();
	void FDReadSocket();
	void MakeTelnetReply(char* buf);
	BOOL AsyncSelect(HWND hWnd);
	SOCKET ListenSocket;
	CString IPAddress;
	CString chLastSent;
// Operations
public:
	CTelnetServer(int port, HWND hwnd);
	virtual ~CTelnetServer();
// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTelnetServer)
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CTelnetServer)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TELNETSERVER_H__C6AEB3B2_1678_40C3_80DB_FE1D135BF17B__INCLUDED_)
