// TelnetClientDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TelnetClient.h"
#include "TelnetClientDlg.h"
#include <mmsystem.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTelnetClientDlg dialog

void Sleep2(int nTime)
{
	DWORD time1, time2;
	time1 = timeGetTime();
	time2 = time1;
	while(time2-time1<nTime)
	{
		MSG msg;
		while (PeekMessage(&msg, NULL, NULL, NULL, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		time2 = timeGetTime();
	}
}

CTelnetClientDlg::CTelnetClientDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTelnetClientDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTelnetClientDlg)
	m_bConnect = FALSE;
	m_chIPaddress = _T("0.0.0.0");
	m_nPort = 23;
	m_chReplyStr = _T("");
	m_chString2send = _T("GETDATA");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	pThread = NULL;
	hSocket = NULL;
}

void CTelnetClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTelnetClientDlg)
	DDX_Check(pDX, IDC_CONNECT, m_bConnect);
	DDX_Text(pDX, IDC_IPADDRESS, m_chIPaddress);
	DDV_MaxChars(pDX, m_chIPaddress, 50);
	DDX_Text(pDX, IDC_PORT, m_nPort);
	DDX_Text(pDX, IDC_REPLYSTRING, m_chReplyStr);
	DDX_Text(pDX, IDC_STRING2SEND, m_chString2send);
	DDV_MaxChars(pDX, m_chString2send, 255);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTelnetClientDlg, CDialog)
	//{{AFX_MSG_MAP(CTelnetClientDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CONNECT, OnConnect)
	ON_BN_CLICKED(IDC_SEND, OnSend)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTelnetClientDlg message handlers

BOOL CTelnetClientDlg::OnInitDialog()
{

	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	char winini[MAX_PATH];

	GetModuleFileName(NULL, winini, 255);
	_splitpath(winini, drive, dir, fname, ext ); 
	_makepath(winini, drive, dir, "Configuration", "ini");
	
	char str[64]; sprintf(str, "%s", m_chIPaddress);
	GetPrivateProfileString("Telnet", "IPAddress", str, str, 64, winini);
	m_chIPaddress.Format("%s", str);
	int n = m_nPort;
	n = GetPrivateProfileInt("Telnet", "port", n, winini);
	m_nPort = n;

	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTelnetClientDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTelnetClientDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTelnetClientDlg::OnConnect() 
{
	// TODO: Add your control notification handler code here
	CString str;
	m_bConnect = !m_bConnect;	
	if (m_bConnect)
	{
		UpdateData(TRUE);

		hSocket = Connect((char*) m_chIPaddress.GetBuffer(0), m_nPort);
		if (hSocket == NULL )
		{
			AfxMessageBox("Unable To Connect");
			return;
		}
		if (pThread)
			pThread->ResumeThread();
		else
			pThread = AfxBeginThread(ThreadProc, this);
		str.Format ("%s", "Disconnect");
	}
	else
	{
		if (pThread)
			pThread->SuspendThread();
		Disconnect();
		str.Format ("%s", "Connect");
	}
	GetDlgItem(IDC_SEND)->EnableWindow(m_bConnect);
	GetDlgItem(IDC_IPADDRESS)->EnableWindow(!m_bConnect);
	GetDlgItem(IDC_PORT)->EnableWindow(!m_bConnect);
	SetDlgItemText(IDC_CONNECT, str);
}

void CTelnetClientDlg::OnSend() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	char pBuf[512];
	memset(pBuf, 0, 512);
	sprintf((char*) pBuf, "%s\r", m_chString2send);
	int nRet = send(hSocket,(char*) pBuf, m_chString2send.GetLength()+1,0);
}

void CTelnetClientDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	if (m_bConnect)
	{
		AfxMessageBox("Disconnect from the server first");
		return;
	}
	if (pThread)
	{
		WaitForSingleObject((HANDLE) pThread, 1000);
		pThread->SuspendThread();
		delete pThread;
	}
	CDialog::OnClose();
}

UINT CTelnetClientDlg::ThreadProc(LPVOID pParam)
{
	CTelnetClientDlg* p  = (CTelnetClientDlg*) pParam;
	int n = 0, nRet, index=0;
	char pBuf[512];
	memset(pBuf, 0, 512);
	for (;;)
	{
		if (p && p->m_bConnect)
		{
		    nRet = recv(p->hSocket,pBuf+index,sizeof(pBuf)-index,0);
			if (nRet>511-index)
				nRet=511-index;
			if (nRet<0)
				nRet = 0;
		}
		if (nRet>0)
		{
			index += nRet;
			p->SetDlgItemText(IDC_REPLYSTRING, pBuf);
			if (pBuf[nRet-1]==13)
			{
				memset(pBuf, 0, 512);
				index=0;
			}
		}
		Sleep2(25);

	}
	return 0;
}

SOCKET CTelnetClientDlg::Connect(char *strIP,int nPort)
{
  unsigned long ip;
  sockaddr_in m_sockaddr_in;
  int nRet;

  if((*strIP <= '9') && (*strIP >= '0'))
  {
     if((ip = inet_addr(strIP)) == INADDR_NONE)
       printf("invalid host ip given");
  }
  else
  {
    hostent* ent = gethostbyname(strIP);
    if(!ent) printf("\nError\n");
    ip = *(unsigned long*)(ent->h_addr);
  }

	m_sockaddr_in.sin_family = AF_INET;
	m_sockaddr_in.sin_port = htons(nPort);
	m_sockaddr_in.sin_addr = *(in_addr*)&ip;

	hSocket = socket(PF_INET,SOCK_STREAM,IPPROTO_TCP);
	if ( hSocket == INVALID_SOCKET) return NULL;

	nRet = connect(hSocket,(sockaddr*)&m_sockaddr_in,sizeof(sockaddr));
	if ( nRet == SOCKET_ERROR ) return NULL;

	return hSocket;
}

void CTelnetClientDlg::Disconnect()
{
	closesocket(hSocket);
}

