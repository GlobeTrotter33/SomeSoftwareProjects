// TelnetClientDlg.h : header file
//

#if !defined(AFX_TELNETCLIENTDLG_H__61FB7D30_7386_4DA0_8026_5FB8D3851923__INCLUDED_)
#define AFX_TELNETCLIENTDLG_H__61FB7D30_7386_4DA0_8026_5FB8D3851923__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#include "TelnetClt.h"
/////////////////////////////////////////////////////////////////////////////
// CTelnetClientDlg dialog

class CTelnetClientDlg : public CDialog
{
// Construction
public:
	CTelnetClientDlg(CWnd* pParent = NULL);	// standard constructor

//	CTelnetClt* pTelnetClt;
	CWinThread* pThread;
	SOCKET hSocket;
	SOCKET Connect(char *strIP,int nPort);
	void Disconnect();
// Dialog Data
	//{{AFX_DATA(CTelnetClientDlg)
	enum { IDD = IDD_TELNETCLIENT_DIALOG };
	BOOL	m_bConnect;
	CString	m_chIPaddress;
	int		m_nPort;
	CString	m_chReplyStr;
	CString	m_chString2send;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTelnetClientDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	static UINT ThreadProc(LPVOID pParam);
	// Generated message map functions
	//{{AFX_MSG(CTelnetClientDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnConnect();
	afx_msg void OnSend();
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TELNETCLIENTDLG_H__61FB7D30_7386_4DA0_8026_5FB8D3851923__INCLUDED_)
