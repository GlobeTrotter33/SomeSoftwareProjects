// TelnetClient.h : main header file for the TELNETCLIENT application
//

#if !defined(AFX_TELNETCLIENT_H__62EF7581_E1D4_47CA_BB5E_DE97146693EC__INCLUDED_)
#define AFX_TELNETCLIENT_H__62EF7581_E1D4_47CA_BB5E_DE97146693EC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CTelnetClientApp:
// See TelnetClient.cpp for the implementation of this class
//

class CTelnetClientApp : public CWinApp
{
public:
	CTelnetClientApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTelnetClientApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTelnetClientApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TELNETCLIENT_H__62EF7581_E1D4_47CA_BB5E_DE97146693EC__INCLUDED_)
