// LCV.cpp by GlobeTrotter33
// a hidden program, which occupies a piece of hardware (COM1 in this example), so other programs can't use it

#include "stdafx.h"
#include "stdio.h"

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	BOOL bRet = TRUE;
	HWND m_hWnd = NULL;
	HANDLE hSerialPort = NULL;
	int nSerialPort = 1;//for example, open COM=1
//let's open com port
	char strSerialPort[50];
	int nError = 0;

	sprintf(strSerialPort, "\\\\.\\COM%u", nSerialPort); // \\\\.\\ added just in case, for COM ports >9 (COM10, COM11. etc.)

	hSerialPort = ::CreateFile(strSerialPort, GENERIC_READ|GENERIC_WRITE,
		0, NULL, OPEN_EXISTING, NULL, NULL);
	if (hSerialPort == INVALID_HANDLE_VALUE)
	{
		return FALSE;
	}
	else
	{
// let's create program window
		const wchar_t CLASS_NAME[]  = L"CWL";
    
		WNDCLASS wc;
		memset(&wc, 0, sizeof(WNDCLASS));//= { };

		wc.lpfnWndProc   = WindowProc;
		wc.hInstance     = hInstance;
		wc.lpszClassName = (LPSTR) CLASS_NAME;
		RegisterClass(&wc);		
		m_hWnd = CreateWindowEx(0, (LPSTR) CLASS_NAME, "LCV", WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance, NULL); 
		if (!m_hWnd)
			nError = GetLastError();
//...
		RECT rc;
		::GetClientRect(m_hWnd, &rc);	
//		rc.left = rc.right-20;
//		rc.top = rc.bottom-20;
//...
	}
//now let's hide program window
	bRet = ShowWindow(m_hWnd, SW_FORCEMINIMIZE | SW_HIDE);
	bRet = DestroyWindow(m_hWnd);
	if (!bRet)
		nError = GetLastError();
	while(1) //the program will run forever, until it's killed from Task Manager
	{
/*		MSG msg;
		while (PeekMessage(&msg, NULL, NULL, NULL, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}*/
		;;
	}
	return 0;
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
    case WM_DESTROY:
        PostQuitMessage(0);
  //      return 0;

    case WM_PAINT:
        {
 /*           PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hwnd, &ps);

            FillRect(hdc, &ps.rcPaint, (HBRUSH) (COLOR_WINDOW+1));

            EndPaint(hwnd, &ps);*/
        }
        return 0;

    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}



